package q01.quiz01;

public class quiz07_5 {

	public static void main(String[] args) {
		int value = 356;
		System.out.println((value / 100)*100);

	}

}
