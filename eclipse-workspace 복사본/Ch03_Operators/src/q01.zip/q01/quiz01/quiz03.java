package q01.quiz01;

import java.util.Scanner;

public class quiz03 {                

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("매달 넣을 원금을 입력해주세요.");
		double money = input.nextDouble();
		
		System.out.println("연이율(~~%)를 입력해주세요.");
		double month_interest_rate = 1+((input.nextDouble()/100)/12);
		
		double month1 = money * month_interest_rate;
		double month2 = (money + month1) * month_interest_rate;
		double month3 = (money + month2) * month_interest_rate;
		double month4 = (money + month3) * month_interest_rate;
		double month5 = (money + month4) * month_interest_rate;
		double month6 = (money + month5) * month_interest_rate;
		

		
		
		System.out.println( "6개월 후 적금 총금액은 원금 " + month6 + "원 입니다.");


	}

}
