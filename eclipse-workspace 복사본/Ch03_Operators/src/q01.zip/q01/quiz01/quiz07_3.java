package q01.quiz01;

public class quiz07_3 {

	public static void main(String[] args) {
		int score = 85;
		String result = (!(score>90))? "가":"나";
		System.out.println(result);
	}

}
